const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const  Produto = sequelize.define('Produto', {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    preco: {
        type: DataTypes.STRING,
        allowNull: false
    },
    categoria: {
        type: DataTypes.STRING,
        allowNull: false
    },
    descricao: {
        type: DataTypes.STRING,
        allowNull: false
    }

})

module.exports = Produto;